import re
import os

class Operation:
    #Fonction qui initie le nom, les detialles et le niveau (indentation) de l'opération donné
    def __init__(self, nom, details, level):
        self.nom = nom
        self.details = details
        self.level = level
        self.explication = self.generer_explication()

    #Récupération des opérations et de leurs explications
    def generer_explication(self):
        nom = self.nom.lower()
        if "seq scan" in nom:
            return "Scan séquentiel : parcourt chaque ligne de la table."
        elif "index scan" in nom:
            return "Index Scan : utilise un index pour trouver les lignes correspondantes."
        elif "bitmap" in nom:
            return "Bitmap Index Scan : Utilise un index pour créer un bitmap des lignes à lire."
        elif "nested loop" in nom:
            return "Boucle imbriquée : pour chaque ligne de la table externe, parcourt la table interne."
        elif "hash join" in nom:
            return "Hash Join : utilise une table de hachage pour joindre les tables."
        elif "merge join" in nom:
            return "Merge Join : trie les deux tables puis les joint."
        elif "hash aggregate" in nom:
            return "Hash aggregate : utilise une table de hachage pour agréger les résultats."
        elif "limit" in nom:
            return "Limit : restreint le nombre de lignes retournées"
        elif "sort" in nom:
            return "Sort : trie les résultats."
        elif "aggregate" in nom:
            return "Agrégation : calcule des sommes, moyennes, etc."
        elif "unique" in nom:
            return "Unique : élimine les doublons"
        elif "gather" in nom:
            return "Gather : rassemble les résultats de processus parallèles."
        elif "gather merge" in nom:
            return "Gather Merge : rassemble et trie les résultats parallèles."
        elif "filter" in nom:
            return "Filtre : filtre la collonne spécifié."
        else:
            return "Opération inconnue ou spécifique"

    #fonction qui retourne le résultat 
    def __repr__(self):
        indent = "  " * self.level
        return f"{indent}- {self.nom} ({self.details})\n{indent}  {self.explication}"

def parse_plan(plan_text):
    lignes = plan_text.strip().splitlines()
    operations = []
    stack = []
    regex = re.compile(r"^(\s*)([A-Za-z ].*?)\s+\((.*)\)$")

    for ligne in lignes:
        li = ligne.strip()
        match = regex.match(li)
        if not match:
            continue
        indent = len(match.group(1)) // 2
        nom = match.group(1).strip()
        details = match.group(3).strip()

        op = Operation(nom, details, indent)

        while stack and stack[-1].level >= indent:
            stack.pop()

        operations.append(op)
        stack.append(op)

    return operations
        
def analyse(fichier):
    if not os.path.exists(fichier):
        print('aucun fichier')
        return
    
    with open(fichier, 'r') as f:
        contenu = f.read()
        
    operations = parse_plan(contenu)
    print('analyse du plan : \n')
    for op in operations:
        print(op)

if __name__ == "__main__":
    fichier = "Plan1.txt"
    analyse(fichier)