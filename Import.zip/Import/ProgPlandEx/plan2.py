import re

# Explications des opérations
EXPLANATIONS = {
    "seq scan": "Scan séquentiel : parcourt chaque ligne de la table.",
    "parallel seq scan": "Scan séquentiel parallèle : parcourt chaque ligne de la table en parallèle.",
    "index scan": "Index Scan : utilise un index pour trouver les lignes correspondantes.",
    "bitmap": "Bitmap Index Scan : utilise un index pour créer un bitmap des lignes à lire.",
    "nested loop": "Boucle imbriquée : pour chaque ligne de la table externe, parcourt la table interne.",
    "hash join": "Hash Join : utilise une table de hachage pour joindre les tables.",
    "merge join": "Merge Join : trie les deux tables puis les joint.",
    "hash aggregate": "Hash aggregate : utilise une table de hachage pour agréger les résultats.",
    "limit": "Limit : restreint le nombre de lignes retournées.",
    "sort": "Sort : trie les résultats.",
    "aggregate": "Agrégation : calcule des sommes, moyennes, etc.",
    "unique": "Unique : élimine les doublons.",
    "gather": "Gather : rassemble les résultats de processus parallèles.",
    "gather merge": "Gather Merge : rassemble et trie les résultats parallèles.",
}

#liste les opérations sous format keys-values
OPERATORS = list(EXPLANATIONS.keys())

#classe qui "tri" les informations
class Node:
    
    #fonction d'initialisation d'objet selon la catégorie de l'information
    def __init__(self, line_num, raw, operator, explanation, time=None, depth=0):
        self.line_num = line_num
        self.raw = raw
        self.operator = operator
        self.explanation = explanation
        self.time = time
        self.depth = depth
        self.details = []

    #fonction pour ajouter l'information à l'objet
    def add_detail(self, text):
        self.details.append(text)

#initialisation d'un tableau de noeuds vide
nodes = []
current_node = None

#lecture du fichier de plan d'execution
with open("Plan1.txt", "r") as fichier:
    
    #boucle qui parcourt les lignes
    for lineno, ligne in enumerate(fichier, start=1):
        
        stripped = ligne.strip()
        
        #trie des lignes selon les opérateurs "principaux"
        indent = ligne.count('->')

        # Cherche opérateur
        found_op = None
        for op in OPERATORS:
            if re.search(rf"\b{re.escape(op.title())}\b", ligne):
                found_op = op.title()
                break

        # Temps d'exécution
        time = None
        
        #récupération des temps (avant et après execution)
        m_time = re.search(r"actual time=([\d\.]+)\.\.([\d\.]+)", ligne)
        
        #calcul du temp d'execution 
        if m_time:
            start = float(m_time.group(1))
            end = float(m_time.group(2))
            time = end - start

        if '->' in ligne or found_op:
            # Explication dynamique pour Seq Scan et Parallel Seq Scan
            if found_op and 'seq scan' in found_op.lower():
                # Cherche le nom de la table après 'on'
                m_table = re.search(r"on\s+(\w+)", ligne, re.IGNORECASE)
                #boucle imbriquer pour recherche des parallèle seq scan 
                if m_table:
                    table_name = m_table.group(1)
                    if 'parallel' in found_op.lower():
                        expl = f"Scan séquentiel parallèle : parcourt chaque ligne de la table `{table_name}` en parallèle."
                    else:
                        expl = f"Scan séquentiel : parcourt chaque ligne de la table `{table_name}`."
                else:
                    expl = EXPLANATIONS.get(found_op.lower(), "Opération inconnue ou spécifique.")
            else:
                expl = EXPLANATIONS.get(found_op.lower(), "Opération inconnue ou spécifique.")
                
            current_node = Node(
                line_num=lineno,
                raw=stripped,
                operator=found_op if found_op else "Inconnu",
                explanation=expl,
                time=time,
                depth=indent
            )
            nodes.append(current_node)
        else:
            if current_node:
                current_node.add_detail(stripped)

# Inverser pour lecture bas-haut
nodes = list(reversed(nodes))

# Générer le HTML

#header + style
html = """<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Explain Visualizer</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; }
    .node { margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9; }
    .operator { font-weight: bold; color: #333; }
    .raw { font-family: monospace; color: #555; }
    .explanation { margin-top: 10px; white-space: pre-wrap; color: #0074D9; }
    .detail { margin-left: 20px; color: #555; }
  </style>
</head>
<body>
  <h1>Plan d'Exécution</h1>
"""
#insertion de chaque noeud pour chaque opération 
for node in nodes:
    margin = node.depth * 30
    html += f"""
  <div class="node" style="margin-left: {margin}px">
    <div class="operator">Ligne {node.line_num} : {node.operator}</div>
    <div class="raw">{node.raw}</div>
    <div class="explanation">{node.explanation}"""
    if node.time is not None:
        html += f"\n Temps d'exécution total : {node.time:.3f} ms"
    html += "</div>"
    for detail in node.details:
        html += f"<div class='detail'>{detail}</div>"
    html += "</div>"

html += "</body></html>"

#ecriture dans le fichier html
with open("explain.html", "w", encoding="utf-8") as f:
    f.write(html)

print("Plan d'exécution généré avec le nom de table pour Seq Scan : explain.html")