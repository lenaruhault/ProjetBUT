# don't specify hash bang as ksh is not always installed on Nubo
#
# check postgres config and report wrong params with warn or error status
#
# Bug: on multi-cluster platform, pgchkconf reports wrong recommanded Memory parameters as it can only analyze one cluster.
# Manual config must be done in this case.
#
#  ----------------------------------------------------------------------------
#  Mar 2023, bortzy, v1.0:      creation
#  Apr 2023,         v1.1:      add hugepage warn, cluster_name, bug on THP
#  	             v1.2:      add archive_mode, replication
#  	             v1.3:      add wal_size control
#  May 2023,	     v1.4:	add databases info
#  Aug 2023,	     v1.5:	add autovacuum test
#  Dec 2023,	     v1.6:	use two sections: Description and Parameters
#  ----------------------------------------------------------------------------

# set american language
LANG=en_US.UFT-8

# light colors messages
err="\E[1;31m"  # red
ok="\E[1;32m"   # green
warn="\E[1;33m" # yellow
dflt="\E[0m"    # normal

# command line analyze
if [ $# -ne 0 ]
then
  echo -e "\nUsage: [PGPORT=...] $0\n\nCheck postgres config and report wrong params with ${warn}warn${dflt} or ${err}error${dflt} status.\n"
  exit 1
fi

if ! psql -l >&-
then
  echo -e "\n${err}Error detected${dflt} while calling psql! Wrong PGPORT setting or is cluster running?"
  exit 1
fi

CFG=/tmp/${0##*/}.cfg

if [ ! -w /tmp ]
then
  echo -e "${err}Error${dflt}: can't write to /tmp!"
  exit 1
fi

psql -AF\  << %% > $CFG

-- version
show server_version;
show cluster_name;

-- databases
select datname dbname, pg_size_pretty(pg_database_size(datname)) size
from pg_database
where datistemplate = false
and datname != 'postgres'
;

-- directories
show data_directory;
show log_directory;

-- replication
select state
from pg_stat_replication;

-- wal
show archive_mode;
show wal_compression;
show checkpoint_timeout;
show checkpoint_completion_target;
show max_wal_size;
show min_wal_size;

-- RAM
show max_stack_depth;
show max_prepared_transactions;
show shared_buffers;
show effective_cache_size;
show work_mem;
show maintenance_work_mem;
show temp_buffers;
show max_connections;

-- planner
show random_page_cost;
show effective_io_concurrency;
show autovacuum;
%%


if [ ! -r $CFG ]
then
  echo -e "\n${err}Error${dflt}: can't read file $CFG!"
  exit 1
fi

awk '
BEGIN { # light colors messages
        err = "\033[1;31m"
        ok = "\033[1;32m"
        warn = "\033[1;33m"
        dflt = "\033[0m"
	
        # determine platform type: Nubo or DGFiP socle?
	if( getline < "/etc/pgsql/pgtab" == -1 )
	  TYPE="nubo"
	else
	  TYPE="socle"
	print "Description\n-----------"
	print "Platform type:\t\t\t\t" TYPE

	# get server RAM size
	getline < "/proc/meminfo"
        RAM = int($2 / 2^20) + 4 - int($2 / 2^20) % 4
	print "RAM size:\t\t\t\t" RAM, "Gb"

	# get Hugepage#
	while( getline < "/proc/meminfo" == 1 ) 
	  if( /^HugePages_Total:/ ) 
	  { # warn if RAM >= 4g and not enough pages
	    if( RAM >= 16 && $2 * 2048 < RAM * 1024 / 4 )
	      print warn "Hugepage defined:\t\t\t" $2 dflt
	    else
	      print "Hugepage defined:\t\t\t" $2 
	    break 
	  } 

	# get THP status
	getline < "/sys/kernel/mm/transparent_hugepage/enabled"
	for(i = 1 ; i <= NF ; i++)
	  if( $i ~ /^\[/ )
          { if( $i != "[never]" )
	      print err "THP status:\t\t\t\t" $i dflt, "recommanded: [never]"
            else
	      print "THP status:\t\t\t\t" $i
            break
          }
      }

function to_second( t )
{  # return the time in seconds

   if( t ~ /min/ )
   {  sub("min", "", t)
      t *= 60
   }

   if( t ~ /h/ )
   {  sub("h", "", t)
      t *= 60 * 60
   }

   if( t ~ /d/ )
   {  sub("d", "", t)
      t *= 60 * 60 * 24
   }

   if( t ~ /s/ )
   {  sub("s", "", t)
   }

   return( t )
}

function to_byte( b )
{  # return the buffer in bytes

   if( b ~ /kB/ )
   {  sub("kB", "", b)
      b *= 1024
   }

   if( b ~ /MB/ )
   {  sub("MB", "", b)
      b *= 2^20
   }

   if( b ~ /GB/ )
   {  sub("GB", "", b)
      b *= 2^30
   }

   if( b ~ /B/ )
   {  sub("B", "", b)
   }

   return( b )
}


($1 == "server_version") { getline
                           print "Postgres version:\t\t\t" $1
			 }

($1 == "cluster_name") { getline
                         print "Cluster name:\t\t\t\t" $1
		       }

($1 == "dbname") { # get all databases
		   getline
                   while( !/row/ )
                   { db = db " " $0
		     getline
		   }

		   print "Databases:\t\t\t\t" db
		 }

($1 == "data_directory") { getline
		           dd = $0
                           print "data_directory:\t\t\t\t" dd
                         }

($1 == "log_directory") { getline
		          if( $0 ~ /^\// )
		            print "log_directory:\t\t\t\t" $0
                          else
		            print "log_directory:\t\t\t\t" dd "/" $0
                        }

($1 == "archive_mode") { getline
		         print "archive_mode:\t\t\t\t" $0
                       }

($1 == "state") { getline
                  if( /rows/ )
		    print "replication:\t\t\t\tnone"
		  else
		    print "replication:\t\t\t\t" $1

		  print "\nParameters\n----------"
		}

($1 == "wal_compression") { getline
		            if( $1 == "off" )
		              print "wal_compression:\t\t\tdetected: OFF recommanded: ON"
                          }

($1 == "checkpoint_timeout") { getline
		               if( to_second( $1 ) < 15 * 60 )
			         print "checkpoint_timeout:\t\t\tdetected:", $1, "recommanded: 15min"
		             }

($1 == "checkpoint_completion_target") { getline
                                         if( $1 < .9 )
				           print "checkpoint_completion_target:\t\tdetected:", $1, "recommanded: .9"
			               }

($1 == "max_wal_size") { getline
                         if( to_byte($1) < 5 * 2^30 )
                           print err "max_wal_size:\t\t\t\tdetected:", $1, dflt "recommanded: 10GB" 
                         else
                           if( to_byte($1) < 10 * 2^30 )
                             print warn "max_wal_size:\t\t\t\tdetected:", $1, dflt "recommanded: 10GB" 
		       }

($1 == "min_wal_size") { getline
                         if( to_byte($1) < 500 * 2^20 )
                           print err "min_wal_size:\t\t\t\tdetected:", $1, dflt "recommanded: 1GB" 
                         else
                           if( to_byte($1) < 2^30 )
                             print warn "min_wal_size:\t\t\t\tdetected:", $1, dflt "recommanded: 1GB" 
		       }
                             
($1 == "max_stack_depth") { getline
                            "ulimit -s" | getline ulimit
		            if( to_byte($1) != ulimit * 1024 - 2^20 )
		              print "max_stack_depth:\t\t\tdetected:", $1, "recommanded:", int(ulimit / 1024) - 1 "MB"
		          }

($1 == "max_prepared_transactions") { getline
                                      if( $1 != 0 )
				        print err "max_prepared_transactions:\t\tdetected:", $1, dflt "recommanded: 0"
			            }

($1 == "shared_buffers") { getline
                           if( to_byte($1) != int(RAM * 2^30 / 4) )
		             print err "shared_buffers:\t\t\t\tdetected:", $1, dflt "recommanded: " int(RAM / 4) "GB"
		         }

($1 == "effective_cache_size") { getline
                                 if( to_byte($1) != int(RAM * 2^30 * .75) )
		                   print err "effective_cache_size:\t\t\tdetected:", $1, dflt "recommanded: " int(RAM * .75) "GB"
		               }

($1 == "work_mem") { getline
                     if( to_byte($1) < 16 * 2^20 )
                       print warn "work_mem:\t\t\t\tdetected:", $1, dflt "recommanded: >= 16MB"
	           }

($1 == "maintenance_work_mem") { getline
                                 if( to_byte($1) < 2^30 )
                                   print warn "maintenance_work_mem:\t\t\tdetected:", $1, dflt "recommanded: >= 1GB"
		               }

($1 == "temp_buffers") { getline
                         if( to_byte($1) < 16 * 2^20 )
                           print warn "temp_buffers:\t\t\t\tdetected:", $1, dflt "recommanded: >= 16MB"
	               }

($1 == "max_connections") { getline
                            print "max_connections:\t\t\tdetected:", $1, "--> check with tomcat connection params"
		          }

($1 == "random_page_cost") { getline
                             if( TYPE == "socle" && $1 > 1 )
                               print warn "random_page_cost:\t\t\tdetected:", $1, dflt "recommanded: 1"
		           }

($1 == "effective_io_concurrency") { getline
                                     if( TYPE == "socle" && $1 < 500 )
                                       print warn "effective_io_concurrency:\t\tdetected:", $1, dflt "recommanded: 500"
			           }
($1 == "autovacuum") { getline
		       if( $1 == "off" )
		         print err "autovacuum:\t\t\tdetected: OFF", dflt, "recommanded: ON"
                     }

' $CFG

rm $CFG

